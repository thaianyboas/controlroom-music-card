
 // lovelace card imports.
import { html, PropertyValues, TemplateResult } from 'lit';
import { customElement } from 'lit/decorators.js';

// our imports.
import '../components/media-browser-list';
import '../components/media-browser-icons';
import '../components/playlist-actions';
import { FavBrowserBase } from './fav-browser-base';
import { Section } from '../types/section';
import { MediaPlayer } from '../model/media-player';
import { formatTitleInfo } from '../utils/media-browser-utils';
import { getHomeAssistantErrorMessage, getUtcNowTimestamp } from '../utils/utils';
import { IPlaylistSimplified } from '../types/spotifyplus/playlist-simplified';
import { resolveLanguage } from '../localization/i18n';
import {
  EDITOR_DEFAULT_BROWSER_ITEMS_PER_ROW,
} from '../constants';


@customElement("crm-playlist-fav-browser")
export class PlaylistFavBrowser extends FavBrowserBase {

  /** Array of items to display in the media list. */
  protected override mediaList!: Array<IPlaylistSimplified> | undefined;


  /**
   * Initializes a new instance of the class.
   */
  constructor() {

    // invoke base class method.
    super(Section.PLAYLIST_FAVORITES);

  }


  /**
   * Invoked on each update to perform rendering tasks.
   * This method may return any value renderable by lit-html's ChildPart.
   */
  protected render(): TemplateResult | void {

    // Detect Home Assistant language automatically.
    const language = resolveLanguage(
      'auto',
      this.store.hass?.locale?.language || this.store.hass?.language
    );

    const placeholders = {
      de: 'Nach Playlistnamen filtern',
      pt: 'Filtrar por nome da playlist',
      en: 'Filter by playlist name',
    };

    this.filterCriteriaPlaceholder = placeholders[language];

    // invoke base class method.
    super.render();

    // filter items (if actions are not visible).
    let filteredItems: Array<IPlaylistSimplified> | undefined;
    if (!this.isActionsVisible) {
      const filterName = (this.filterCriteria || "").toLocaleLowerCase();
      filteredItems = this.mediaList?.filter((item: IPlaylistSimplified) => (item.name.toLocaleLowerCase().indexOf(filterName) !== -1));
      this.filterItemCount = filteredItems?.length;
    }

    // format title and sub-title details.
    const title = formatTitleInfo(this.config.playlistFavBrowserTitle, this.config, this.player, this.mediaListLastUpdatedOn, this.mediaList, filteredItems);
    const subtitle = formatTitleInfo(this.config.playlistFavBrowserSubTitle, this.config, this.player, this.mediaListLastUpdatedOn, this.mediaList, filteredItems);

    // set auto-shuffle based on configuration option.
    this.shuffleOnPlay = this.config.playlistFavBrowserShuffleOnPlay || false;

    // load default # of items per row to display.
    if (!this.favBrowserItemsPerRow) {
      this.favBrowserItemsPerRow = this.config.playlistFavBrowserItemsPerRow || EDITOR_DEFAULT_BROWSER_ITEMS_PER_ROW;
    }

    // render html.
    return html`
      <div class="media-browser-section" style=${this.styleMediaBrowser()}>
        ${title ? html`<div class="media-browser-section-title">${title}</div>` : html``}
        ${subtitle ? html`<div class="media-browser-section-subtitle">${subtitle}</div>` : html``}
        <div class="media-browser-controls">
          ${!(this.isActionsVisible || false) ? html`` : html`${this.btnHideActionsHtml}`}
          ${this.filterCriteriaHtml}${this.formatMediaListHtml}${this.refreshMediaListHtml}
        </div>
        <div id="mediaBrowserContentElement" class="media-browser-content">
          ${this.alertError ? html`<ha-alert alert-type="error" dismissable @alert-dismissed-clicked=${this.alertErrorClear}>${this.alertError}</ha-alert>` : ""}
          ${this.alertInfo ? html`<ha-alert alert-type="info" dismissable @alert-dismissed-clicked=${this.alertInfoClear}>${this.alertInfo}</ha-alert>` : ""}
          ${(() => {
            // if actions are not visible, then render the media list.
            if (!this.isActionsVisible) {
              if (this.favBrowserItemsPerRow === 1) {
                return (
                  html`<crm-media-browser-list
                        class="media-browser-list"
                        .items=${filteredItems}
                        .itemsPerRow=${this.favBrowserItemsPerRow}
                        .store=${this.store}
                        @item-selected=${this.onItemSelected}
                        @item-selected-with-hold=${this.onItemSelectedWithHold}
                       ></crm-media-browser-list>`
                )
              } else {
                return (
                  html`<crm-media-browser-icons
                        class="media-browser-list"
                        .items=${filteredItems}
                        .itemsPerRow=${this.favBrowserItemsPerRow}
                        .store=${this.store}
                        @item-selected=${this.onItemSelected}
                        @item-selected-with-hold=${this.onItemSelectedWithHold}
                       ></crm-media-browser-icons>`
                )
              }
            // if actions are visible, then render the actions display.
            } else {
              return html`<crm-playlist-actions class="media-browser-actions" .store=${this.store} .mediaItem=${this.mediaItem}></crm-playlist-actions>`;
            }
          })()}
        </div>
      </div>
    `;
  }


  /**
   * Called when the element has rendered for the first time.
   */
  protected firstUpdated(changedProperties: PropertyValues): void {

    // ensure we are NOT editing the card configuration!
    if (!this.isCardInEditPreview) {

      // set auto-refresh media list flag prior to calling base-class method.
      this.isMediaListRefreshedOnSectionEntry = this.config.playlistFavBrowserItemsRefreshOnEntry || false;
    }

    // invoke base class method.
    super.firstUpdated(changedProperties);
  }


  /**
   * Updates the mediaList display.
   */
  protected override updateMediaList(player: MediaPlayer): boolean {

    // invoke base class method; if it returns false, then we should not update the media list.
    if (!super.updateMediaList(player)) {
      return false;
    }

    try {

      // we use the Promise.allSettled approach here like we do with actions.
      const promiseRequests = new Array<Promise<unknown>>();

      // create promise - get media list.
      const promiseUpdateMediaList = new Promise((resolve, reject) => {

        // set service parameters.
        const limitTotal = this.config.playlistFavBrowserItemsLimit || this.LIMIT_TOTAL_MAX;
        const sortResult = this.config.playlistFavBrowserItemsSortTitle || false;

        // call the service to retrieve the media list.
        this.spotifyPlusService.GetPlaylistFavorites(player, 0, 0, limitTotal, sortResult)
          .then(result => {

            // load media list results.
            this.mediaList = result.items;
            this.mediaListLastUpdatedOn = result.date_last_refreshed || getUtcNowTimestamp();

            // call base class method, indicating media list update succeeded.
            super.updatedMediaListOk();

            // resolve the promise.
            resolve(true);

          })
          .catch(error => {

            // clear results, and reject the promise.
            this.mediaList = undefined;
            this.mediaListLastUpdatedOn = 0;

            // call base class method, indicating media list update failed.
            super.updatedMediaListError("Get Playlist Followed failed: " + getHomeAssistantErrorMessage(error));

            // reject the promise.
            reject(error);

          })
      });

      promiseRequests.push(promiseUpdateMediaList);

      // show visual progress indicator.
      this.progressShow();

      // execute all promises, and wait for all of them to settle.
      Promise.allSettled(promiseRequests).finally(() => {

        // clear the progress indicator.
        this.progressHide();

      });

      return true;

    }
    catch (error) {

      // clear the progress indicator.
      this.progressHide();

      // set alert error message.
      super.updatedMediaListError("Playlist followed refresh failed: " + getHomeAssistantErrorMessage(error));
      return true;

    }
    finally {
    }
  }

}
